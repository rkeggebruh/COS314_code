Files:

I have a Main.java file - this file
runs both the GA algorithm as well 
as the GA with a local search algorithm.

I also have a reader.java file which reads in 
the data from the knapsack instances we were
given.

The item.java file, knapsack.java file and 
LocalSearch.java file are all pretty self 
explanatory and do not hold that much code.

The most important file are GA.java and 
GAWithLS.java.

Execution:

To run the optimization algorithms:

Compile all Java files in the project using the javac command.
Run the Main class (Main.java) to execute both the GA and GA with LS algorithms on the provided knapsack instances.

***Jar file:
Unfortunately due to my file structure I could not get the jar file to work - I did include it in the submission but I highly doubt it will work due to where I placed the knapsack instances folder so I 
just submitted the ZIP of the whole folder structure
to make sure the code will run on your side.